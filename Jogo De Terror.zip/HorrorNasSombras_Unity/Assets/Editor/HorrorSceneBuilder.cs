using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class HorrorSceneBuilder
{
    [MenuItem("Horror nas Sombras/Criar ou reconstruir cena")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        foreach (GameObject go in Object.FindObjectsOfType<GameObject>()) Object.DestroyImmediate(go);
        Scene scene = SceneManager.GetActiveScene();

        RenderSettings.ambientLight = new Color(0.10f,0.10f,0.13f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(0.025f,0.025f,0.035f);
        RenderSettings.fogDensity = 0.025f;

        Material floorMat = Mat(new Color(0.16f,0.15f,0.15f));
        Material wallMat = Mat(new Color(0.20f,0.19f,0.21f));
        Material darkMat = Mat(new Color(0.055f,0.05f,0.06f));
        Material redMat = Mat(new Color(0.55f,0.025f,0.04f), true);
        Material paperMat = Mat(new Color(0.9f,0.84f,0.62f), true);

        Cube("Chão",new Vector3(0,-0.25f,0),new Vector3(24,0.5f,24),floorMat);
        Cube("Parede Norte",new Vector3(0,2,12),new Vector3(24,4,0.5f),wallMat);
        Cube("Parede Sul",new Vector3(0,2,-12),new Vector3(24,4,0.5f),wallMat);
        Cube("Parede Leste",new Vector3(12,2,0),new Vector3(0.5f,4,24),wallMat);
        Cube("Parede Oeste",new Vector3(-12,2,0),new Vector3(0.5f,4,24),wallMat);
        // Divisórias formando corredores, com passagens livres.
        Cube("Divisória 1A",new Vector3(-4,1.6f,3),new Vector3(0.35f,3.2f,8),wallMat);
        Cube("Divisória 1B",new Vector3(4,1.6f,-3),new Vector3(0.35f,3.2f,8),wallMat);
        Cube("Divisória 2",new Vector3(0,1.6f,-7),new Vector3(8,3.2f,0.35f),wallMat);
        Cube("Armário",new Vector3(-8,1,5),new Vector3(1.5f,2,1),darkMat);
        Cube("Mesa",new Vector3(7,0.65f,5),new Vector3(2,1.3f,1),darkMat);

        GameObject player = new GameObject("Jogador");
        player.transform.position = new Vector3(0,0.2f,8);
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.height = 1.8f; cc.radius = 0.32f; cc.center = new Vector3(0,0.9f,0);
        GameObject pivot = new GameObject("CameraPivot");
        pivot.transform.SetParent(player.transform); pivot.transform.localPosition = new Vector3(0,1.58f,0);
        Camera cam = pivot.AddComponent<Camera>(); cam.fieldOfView = 76;
        cam.gameObject.tag = "MainCamera";
        cam.gameObject.AddComponent<AudioListener>();
        PlayerController pc = player.AddComponent<PlayerController>(); pc.cameraPivot = pivot.transform;

        GameObject flashlight = new GameObject("Lanterna");
        flashlight.transform.SetParent(cam.transform); flashlight.transform.localPosition = Vector3.zero;
        Light spot = flashlight.AddComponent<Light>(); spot.type = LightType.Spot; spot.range = 18;
        spot.spotAngle = 58; spot.intensity = 5; spot.color = new Color(0.82f,0.88f,1f);
        spot.shadows = LightShadows.Soft;

        for(int i=0;i<7;i++)
        {
            GameObject lamp = new GameObject("Luz fraca "+i);
            lamp.transform.position = new Vector3((i%2==0?-7:7),3.2f,8-i*2.8f);
            Light l=lamp.AddComponent<Light>(); l.type=LightType.Point; l.range=6; l.intensity=0.55f;
            l.color=new Color(0.55f,0.58f,0.72f);
        }

        Vector3[] pagePositions = { new Vector3(-8,0.45f,-4), new Vector3(8,0.45f,-8), new Vector3(0,0.45f,1) };
        foreach(Vector3 pos in pagePositions)
        {
            GameObject page=GameObject.CreatePrimitive(PrimitiveType.Cube);
            page.name="Página";
            page.transform.position=pos; page.transform.localScale=new Vector3(0.48f,0.06f,0.62f);
            page.GetComponent<Renderer>().sharedMaterial=paperMat;
            Object.DestroyImmediate(page.GetComponent<Collider>());
            page.AddComponent<PagePickup>();
        }

        GameObject monster=GameObject.CreatePrimitive(PrimitiveType.Capsule);
        monster.name="Criatura"; monster.transform.position=new Vector3(8,1,-8);
        monster.transform.localScale=new Vector3(0.8f,2f,0.65f);
        monster.GetComponent<Renderer>().sharedMaterial=darkMat;
        // Olhos luminosos visíveis na criatura.
        Sphere(monster.transform,new Vector3(-0.18f,0.22f,-0.31f),0.09f,redMat);
        Sphere(monster.transform,new Vector3(0.18f,0.22f,-0.31f),0.09f,redMat);
        Object.DestroyImmediate(monster.GetComponent<CapsuleCollider>());

        GameObject door=Cube("Porta de saída",new Vector3(0,1.5f,-11.65f),new Vector3(2,3,0.25f),redMat);
        door.transform.rotation=Quaternion.identity;

        GameObject manager=new GameObject("GameController");
        HorrorGameController gc=manager.AddComponent<HorrorGameController>();
        gc.player=player.transform; gc.monster=monster.transform; gc.exitDoor=door.transform; gc.flashlight=spot;

        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene,"Assets/Scenes/HorrorNasSombras.unity");
        AssetDatabase.SaveAssets();
        EditorUtility.DisplayDialog("Horror nas Sombras","Cena criada! Pressione Play para testar. Controles: WASD, mouse, Shift, F e ESC.","OK");
    }

    static GameObject Cube(string name,Vector3 pos,Vector3 scale,Material mat)
    {
        GameObject go=GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name=name; go.transform.position=pos; go.transform.localScale=scale;
        go.GetComponent<Renderer>().sharedMaterial=mat; return go;
    }
    static void Sphere(Transform parent,Vector3 local, float size,Material mat)
    {
        GameObject go=GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.transform.SetParent(parent); go.transform.localPosition=local; go.transform.localScale=Vector3.one*size;
        go.GetComponent<Renderer>().sharedMaterial=mat; Object.DestroyImmediate(go.GetComponent<Collider>());
    }
    static Material Mat(Color c,bool emission=false)
    {
        Shader s=Shader.Find("Standard");
        Material m=new Material(s); m.color=c;
        if(emission){m.EnableKeyword("_EMISSION");m.SetColor("_EmissionColor",c*1.5f);}
        return m;
    }
}
