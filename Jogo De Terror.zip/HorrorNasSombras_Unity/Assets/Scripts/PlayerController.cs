using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    public Transform cameraPivot;
    public float walkSpeed = 3.2f;
    public float runSpeed = 5.2f;
    public float mouseSensitivity = 2.0f;
    CharacterController controller;
    float pitch;
    float verticalVelocity;

    void Start() { controller = GetComponent<CharacterController>(); }

    void Update()
    {
        if (Time.timeScale == 0f) return;
        float mx = Input.GetAxis("Mouse X") * mouseSensitivity;
        float my = Input.GetAxis("Mouse Y") * mouseSensitivity;
        transform.Rotate(0, mx, 0);
        pitch = Mathf.Clamp(pitch - my, -80f, 80f);
        cameraPivot.localRotation = Quaternion.Euler(pitch,0,0);

        float x = Input.GetAxisRaw("Horizontal");
        float z = Input.GetAxisRaw("Vertical");
        Vector3 move = (transform.right*x + transform.forward*z).normalized;
        float speed = Input.GetKey(KeyCode.LeftShift) ? runSpeed : walkSpeed;

        if (controller.isGrounded && verticalVelocity < 0) verticalVelocity = -2f;
        verticalVelocity += Physics.gravity.y * Time.deltaTime;
        Vector3 velocity = move * speed;
        velocity.y = verticalVelocity;
        controller.Move(velocity * Time.deltaTime);
    }
}
