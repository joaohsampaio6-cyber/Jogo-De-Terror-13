HORROR NAS SOMBRAS — PROJETO UNITY
==================================

Este é um projeto editável para abrir no Unity Editor (não é um arquivo .exe).

COMO ABRIR
1. Extraia o ZIP para uma pasta do computador.
2. Abra o Unity Hub.
3. Clique em Add > Add project from disk.
4. Selecione a pasta "HorrorNasSombras_Unity" que contém Assets, Packages e ProjectSettings.
5. Abra o projeto com Unity 2022.3 LTS ou versão mais recente compatível.
6. No Unity, abra a cena Assets/Scenes/HorrorNasSombras.unity.
   Se a cena ainda não existir, use o menu Horror nas Sombras > Criar ou reconstruir cena.
7. Clique no botão Play (triângulo no topo).

CONTROLES
WASD — andar
Mouse — olhar ao redor
SHIFT — correr
F — ligar/desligar lanterna
ESC — pausar/continuar
Aproxime-se das páginas para coletá-las.
Encontre as 3 páginas e vá até a porta vermelha para vencer.

OBJETIVO
Explorar a casa abandonada, encontrar três páginas e escapar da criatura.
O jogador começa com três vidas.

OBSERVAÇÃO SOBRE A ATIVIDADE
Se o enunciado do professor exigir um asset específico disponibilizado em uma pasta/Google Drive,
importe esse asset no projeto antes de entregar. Esse arquivo não foi incluído neste pacote porque
não estava anexado aqui.
