using UnityEngine;

public class PagePickup : MonoBehaviour
{
    public bool collected = false;
    void Update()
    {
        if (!collected) transform.Rotate(0, 55f * Time.deltaTime, 0, Space.World);
    }
    public void Collect()
    {
        if (collected) return;
        collected = true;
        gameObject.SetActive(false);
    }
}
