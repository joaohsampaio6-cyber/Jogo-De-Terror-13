using UnityEngine;
using UnityEngine.SceneManagement;

public class HorrorGameController : MonoBehaviour
{
    public Transform player;
    public Transform monster;
    public Transform exitDoor;
    public Light flashlight;
    public int pagesNeeded = 3;
    public int lives = 3;

    int pagesFound = 0;
    bool paused = false, finished = false, won = false;
    float nextDamageTime = 0f;
    string message = "Encontre as 3 páginas e fuja da casa.";
    GUIStyle titleStyle, textStyle, buttonStyle;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void Update()
    {
        if (finished) return;
        if (Input.GetKeyDown(KeyCode.Escape)) TogglePause();
        if (paused) return;

        if (Input.GetKeyDown(KeyCode.F) && flashlight != null)
        {
            flashlight.enabled = !flashlight.enabled;
            message = flashlight.enabled ? "Lanterna ligada." : "Lanterna desligada.";
        }

        // Coleta automática ao se aproximar das páginas.
        foreach (PagePickup page in FindObjectsOfType<PagePickup>())
        {
            if (!page.collected && Vector3.Distance(player.position, page.transform.position) < 1.35f)
            {
                page.Collect();
                pagesFound++;
                message = "Página encontrada! (" + pagesFound + "/" + pagesNeeded + ")";
            }
        }

        if (monster != null && player != null)
        {
            float distance = Vector3.Distance(monster.position, player.position);
            float speed = distance < 8f ? 2.35f : 1.15f;
            Vector3 target = new Vector3(player.position.x, monster.position.y, player.position.z);
            monster.position = Vector3.MoveTowards(monster.position, target, speed * Time.deltaTime);
            if (distance < 1.45f && Time.time >= nextDamageTime)
            {
                lives--;
                nextDamageTime = Time.time + 2.0f;
                message = "A criatura encontrou você! Vidas restantes: " + lives;
                if (lives <= 0) Finish(false);
            }
        }

        if (exitDoor != null && Vector3.Distance(player.position, exitDoor.position) < 2.0f)
        {
            if (pagesFound >= pagesNeeded) Finish(true);
            else message = "A saída está trancada. Encontre todas as 3 páginas.";
        }
    }

    void TogglePause()
    {
        paused = !paused;
        Time.timeScale = paused ? 0f : 1f;
        Cursor.lockState = paused ? CursorLockMode.None : CursorLockMode.Locked;
        Cursor.visible = paused;
    }

    void Finish(bool victory)
    {
        finished = true; won = victory;
        Time.timeScale = 0f;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        message = victory ? "VOCÊ ESCAPOU!" : "FIM DE JOGO";
    }

    void OnGUI()
    {
        if (titleStyle == null)
        {
            titleStyle = new GUIStyle(GUI.skin.label) { fontSize = 28, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            titleStyle.normal.textColor = new Color(0.85f,0.12f,0.16f);
            textStyle = new GUIStyle(GUI.skin.label) { fontSize = 17, alignment = TextAnchor.MiddleCenter, wordWrap = true };
            textStyle.normal.textColor = Color.white;
            buttonStyle = new GUIStyle(GUI.skin.button) { fontSize = 18, fixedHeight = 42 };
        }
        GUI.color = new Color(0,0,0,0.65f);
        GUI.Box(new Rect(12,12,340,86),"");
        GUI.color = Color.white;
        GUI.Label(new Rect(22,18,320,30), "PÁGINAS: " + pagesFound + "/" + pagesNeeded, textStyle);
        GUI.Label(new Rect(22,50,320,30), "VIDAS: " + new string('♥', Mathf.Max(0,lives)), textStyle);
        GUI.Label(new Rect(Screen.width/2-8,Screen.height/2-18,20,35), "+", textStyle);
        GUI.Label(new Rect(10,Screen.height-42,Screen.width-20,30), message, textStyle);

        if (paused || finished)
        {
            GUI.color = new Color(0,0,0,0.88f);
            GUI.Box(new Rect(0,0,Screen.width,Screen.height),"");
            GUI.color = Color.white;
            GUI.Label(new Rect(Screen.width/2-250,Screen.height/2-120,500,55),
                finished ? (won ? "VOCÊ ESCAPOU" : "FIM DE JOGO") : "JOGO PAUSADO", titleStyle);
            if (GUI.Button(new Rect(Screen.width/2-110,Screen.height/2-20,220,45),
                finished ? "JOGAR NOVAMENTE" : "CONTINUAR", buttonStyle))
            {
                Time.timeScale = 1f;
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
            if (GUI.Button(new Rect(Screen.width/2-110,Screen.height/2+38,220,42),"SAIR DO JOGO",buttonStyle))
            {
                Time.timeScale = 1f;
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
#else
                Application.Quit();
#endif
            }
        }
    }
}
